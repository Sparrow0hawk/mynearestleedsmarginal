library(testthat)
library(googleway)

test_check("googleway")
