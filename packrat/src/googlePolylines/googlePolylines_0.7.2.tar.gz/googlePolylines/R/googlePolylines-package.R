#' @useDynLib googlePolylines
#' @importFrom Rcpp sourceCpp
#' @importFrom stats setNames
NULL

