library(testthat)
library(googlePolylines)

test_check("googlePolylines")
